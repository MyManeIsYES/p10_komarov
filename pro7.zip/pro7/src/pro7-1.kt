fun main()=try{
    var cable1=Cable_heir(true)
    print("тип кабеля: ")
    cable1.type= readln()
    print("количество жил кабеля: ")
    cable1.number_of_veins= readln()!!.toInt()
    print("диаметр кабеля: ")
    cable1.diameter= readln()!!.toDouble()
    cable1.Info()
    println(cable1.Q())
    cable1.Set_presence_of_braid(false)
    cable1.Info()
    println(cable1.Q())
}
catch (e:NumberFormatException){println("error")}