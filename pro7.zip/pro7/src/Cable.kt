abstract class Cable :Info_Cable{
    var type:String=""
    var number_of_veins: Int=0
    var diameter: Double=0.0
    open fun Q():Double{
        return diameter/number_of_veins
    }
    override fun Info() {
        println("type: $type\nnumber_of_cable_cores: $number_of_veins\ndiameter: $diameter")
    }
}