interface Info_Cable {
    fun Info()
}