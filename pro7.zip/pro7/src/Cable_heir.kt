class Cable_heir(private var presence_of_braid: Boolean):Cable() {
    override fun Q():Double{
        if(presence_of_braid){
            return 2*diameter/number_of_veins
        }
        else{
            return 0.7*diameter/number_of_veins
        }
    }
    override fun Info() {
        println("type: $type\nnumber_of_cable_cores: $number_of_veins\ndiameter: $diameter\npresence_of_braid: $presence_of_braid")
    }
    fun Get_presence_of_braid():Boolean{
        return presence_of_braid
    }
    fun Set_presence_of_braid(presence_of_braid:Boolean){
        this.presence_of_braid=presence_of_braid
    }
}